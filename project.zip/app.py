import requests

API_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJ0aWQiOjYzMTAwODEyOSwiYWFpIjoxMSwidWlkIjoxMDA4MTMwMjYsImlhZCI6IjIwMjYtMDMtMTBUMDU6NTY6MTAuMDAwWiIsInBlciI6Im1lOndyaXRlIiwiYWN0aWQiOjM0MTUzNDQyLCJyZ24iOiJhcHNlMiJ9.VzfjyVRqMJUOELXPOhuMnFFo0DUdt1w2_WuJ_mOoFcU"
DEALS_BOARD_ID = "5027111472"
WORKORDERS_BOARD_ID = "5027111271"

url = "https://api.monday.com/v2"

headers = {
    "Authorization": API_TOKEN
}

def get_board_data(board_id):

    query = f"""
    {{
      boards(ids: {board_id}) {{
        name
        items_page {{
          items {{
            name
            column_values {{
              text
            }}
          }}
        }}
      }}
    }}
    """

    response = requests.post(url, json={'query': query}, headers=headers)

    return response.json()


deals_data = get_board_data(DEALS_BOARD_ID)
workorders_data = get_board_data(WORKORDERS_BOARD_ID)

print("Deals Data:")
print(deals_data)

print("Work Orders Data:")
print(workorders_data)
def extract_items(board_data):

    items = board_data["data"]["boards"][0]["items_page"]["items"]

    cleaned = []

    for item in items:
        name = item["name"]
        values = [col["text"] for col in item["column_values"]]

        cleaned.append({
            "name": name,
            "values": values
        })

    return cleaned
deals_items = extract_items(deals_data)
workorders_items = extract_items(workorders_data)

print("Deals:", deals_items[:5])
print("Work Orders:", workorders_items[:5])
from openai import OpenAI

client = OpenAI(api_key="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")

def ask_ai(question, deals, workorders):

    question = question.lower()

    if "work order" in question:

        total = len(workorders)

        not_started = sum(
            1 for w in workorders
            if any(v == "Not Started" for v in w["values"])
        )

        return f"There are {total} work orders in total. {not_started} are not started yet."

    if "deal" in question or "pipeline" in question:

        total_deals = len(deals)

        return f"There are {total_deals} deals currently in the pipeline."

    if "status" in question:

        status_counts = {}

        for w in workorders:
            for v in w["values"]:
                if v:
                    status_counts[v] = status_counts.get(v, 0) + 1

        return f"Work order status breakdown: {status_counts}"

    if "summary" in question:

        return f"""
Leadership Summary

Total Deals: {len(deals)}
Total Work Orders: {len(workorders)}

Most work orders are currently in 'Not Started' status.
"""

    return "Try asking about deals, pipeline, work orders, or summary."
question = input("Ask a business question: ")

answer = ask_ai(question, deals_items, workorders_items)

print(answer)